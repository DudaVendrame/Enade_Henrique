import fs from 'fs';

interface Veiculo {
  tipo: string;
  marca: string;
  valor: number;
  ano: number;
}

const veiculos: Veiculo[] = JSON.parse(fs.readFileSync('veiculos.json', 'utf-8'));

// Método para filtrar veículos por marca
export const filtrarPorMarca = (marca: string): Veiculo[] => {
  return veiculos.filter(veiculo => veiculo.marca === marca);
};

// Método para somar o valor dos veículos por marca
export const somarValorPorMarca = (marca: string): number => {
  return veiculos
    .filter(veiculo => veiculo.marca === marca)
    .reduce((acc, veiculo) => acc + veiculo.valor, 0);
};

// Método para filtrar veículos mais novos que um determinado ano
export const filtrarPorAno = (ano: number): Veiculo[] => {
  return veiculos.filter(veiculo => veiculo.ano > ano);
};
