import { filtrarPorMarca, somarValorPorMarca, filtrarPorAno } from './veiculos';

test('filtrar veículos por marca', () => {
  const resultado = filtrarPorMarca('Toyota');
  expect(resultado).toEqual([
    { tipo: 'carro', marca: 'Toyota', valor: 50000, ano: 2018 },
    { tipo: 'carro', marca: 'Toyota', valor: 60000, ano: 2021 }
  ]);
});

test('somar valor dos veículos por marca', () => {
  const resultado = somarValorPorMarca('Toyota');
  expect(resultado).toBe(110000);
});

test('filtrar veículos mais novos que o ano informado', () => {
  const resultado = filtrarPorAno(2018);
  expect(resultado).toEqual([
    { tipo: 'moto', marca: 'Honda', valor: 15000, ano: 2020 },
    { tipo: 'carro', marca: 'Toyota', valor: 60000, ano: 2021 }
  ]);
});
